import requests, os

base_dir = os.path.join(os.path.dirname(__file__), 'static', 'images')
os.makedirs(base_dir, exist_ok=True)
urls_file = os.path.join(os.path.dirname(__file__), 'image_urls.txt')

if not os.path.exists(urls_file):
    print('Créé image_urls.txt et ajoute une URL par ligne (Wikimedia Commons, etc.).')
    open(urls_file, 'w').close()
    exit(1)

with open(urls_file, 'r') as f:
    urls = [l.strip() for l in f if l.strip() and not l.strip().startswith('#')]

for i, url in enumerate(urls, start=1):
    try:
        r = requests.get(url, timeout=20)
        r.raise_for_status()
        fname = url.split('/')[-1].split('?')[0]
        if not fname:
            fname = f'image_{i}.jpg'
        path = os.path.join(base_dir, fname)
        with open(path, 'wb') as out:
            out.write(r.content)
        print('Saved', path)
    except Exception as e:
        print('Error downloading', url, e)
