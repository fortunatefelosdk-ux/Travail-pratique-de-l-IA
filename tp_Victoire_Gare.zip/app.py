from flask import Flask, render_template, send_from_directory
import os

app = Flask(__name__, static_folder='static')

@app.route('/')
def index():
    stops = [
        {"name": "Rond-Point Victoire", "lat": -4.3275, "lng": 15.3139, "img": "images/victoire.jpg"},
        {"name": "Avenue Kasa-Vubu", "lat": -4.3232, "lng": 15.3148, "img": "images/kasa_vubu.jpg"},
        {"name": "Boulevard du 30 Juin", "lat": -4.3210, "lng": 15.3175, "img": "images/boulevard.jpg"},
        {"name": "Gare Centrale", "lat": -4.3195, "lng": 15.3110, "img": "images/gare.jpg"},
    ]
    return render_template('index.html', stops=stops)

# Helper to serve static files
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(app.static_folder, filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
