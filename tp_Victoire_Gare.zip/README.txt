TP - Trajet Victoire -> Gare Centrale (Leaflet + Flask)

Contenu:
- app.py : serveur Flask
- templates/index.html : page principale (Leaflet)
- static/css/style.css : styles
- static/images/ : répertoire attendu pour les photos réelles

Instructions pour ajouter des photos réelles:
1) Récupère des photos réelles (Wikimedia Commons, Mapillary, ou prises par toi) et place-les dans 'static/images/'.
   Noms attendus (par défaut):
     - victoire.jpg
     - kasa_vubu.jpg
     - boulevard.jpg
     - gare.jpg
   Tu peux modifier app.py pour changer les noms des fichiers si nécessaire.

2) Optionnel - téléchargement automatique:
   - Remplis 'image_urls.txt' (une URL par ligne) puis exécute 'python fetch_images.py' pour télécharger les images automatiquement.
   - Mapillary nécessite un token/API si tu veux l'utiliser automatiquement.

3) Installation & lancement:
   pip install -r requirements.txt
   python app.py
   Puis ouvre http://127.0.0.1:5000

Remarque: je n'ai pas inclus d'images réelles pour des raisons de licences et couverture. Utilise Wikimedia Commons pour des images libres ou prends tes propres photos.
